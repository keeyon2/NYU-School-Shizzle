We have two main programs.

the assign1 and the QuicksortPackage.


To run, just feed 30 values into assign1.

./assign1 < numbers.txt

After running you will see the 30 initial values.
A blank line
30 sorted values
A blank line
The sum of all the values in the initial array.

The quick sort and the add/Printer/sort operations are all done as their own task as instructed.

Thanks,
Keeyon