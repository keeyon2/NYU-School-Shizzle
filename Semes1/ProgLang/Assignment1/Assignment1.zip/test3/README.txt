We have two main programs.

the assign1 and the QuicksortPackage.


To run, just feed 30 values into assign1.

./assign1 < numbers.txt

Currently the QUicksortPackage has 1 illegal declaration in the task, so the sort isn't compiling, but the does is all there as you can see.  This small issue makes it so the sorting isn't running.  I am submitting now because it is close to the deadline, however I am going to continue to work on this and submit again when fully functional