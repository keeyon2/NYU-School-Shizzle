Extract Keeyon_Ebrahimi_lab_2.tar.gz

#Compile Project
make

# This will create ./output.out
# To run output just type ./output.out with parameters
# Here is example
./output.out -s P2 input0 rfile
